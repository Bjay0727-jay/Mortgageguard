import { useState, useMemo } from "react";

/* ═══ DESIGN TOKENS — Royal Blue / Green / White ═══ */
const T = {
  royal: "#1B3A6B", royalLight: "#2B5298", royalPale: "#E8EEF7", royalMist: "#F4F7FC",
  green: "#0F7B46", greenLight: "#15A35E", greenPale: "#E6F5EE",
  white: "#FFFFFF", g50: "#F8F9FA", g100: "#F1F3F5", g200: "#E2E5E9", g300: "#CED3D9", g500: "#7C8594", g700: "#3D4551", g900: "#1A1D23",
  red: "#C4302B", redPale: "#FEF0EF", amber: "#B8860B", amberPale: "#FFF8E7",
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  radius: "10px", radiusLg: "12px", radiusSm: "6px",
};
const scoreColor = (s) => s >= 80 ? T.green : s >= 50 ? T.amber : T.red;
const scoreBg = (s) => s >= 80 ? T.greenPale : s >= 50 ? T.amberPale : T.redPale;
const fmt = (n) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);

/* ═══ COMPREHENSIVE MOCK DATA ═══ */
const LOANS = [
  { id:"LN-2026-0847", borrower:"Martinez, Elena", state:"TX", property:"4521 Oak Creek Dr, Plano, TX 75024", purpose:"Purchase", product:"Conventional", type:"Fixed", lien:"First", occupancy:"Primary", stage:"Closing", rate:6.375, amount:485000, term:30, docsComplete:38, docsRequired:42, originator:"James Chen", originatorNmls:"1234567", lender:"Wells Fargo", lenderNmls:"399801", appDate:"2026-01-15", closingDate:"2026-03-22", daysInStage:3, score:91, alerts:1, missingDocs:[{name:"Rate Lock Agreement",src:"Federal"},{name:"Appraisal Invoice",src:"Federal"},{name:"Survey Invoice",src:"Federal"},{name:"Flood Certification",src:"Federal"}] },
  { id:"LN-2026-0851", borrower:"Johnson, Marcus", state:"TX", property:"2200 Elm St, Dallas, TX 75201", purpose:"Refinance", product:"FHA", type:"Fixed", lien:"First", occupancy:"Primary", stage:"Processing", rate:5.875, amount:310000, term:30, docsComplete:18, docsRequired:44, originator:"Sarah Kim", originatorNmls:"2345678", lender:"Chase", lenderNmls:"628913", appDate:"2026-02-03", closingDate:null, daysInStage:7, score:41, alerts:4, missingDocs:[{name:"TX Mortgage Company Disclosure",src:"TX"},{name:"Credit Score Disclosure",src:"Federal"},{name:"Appraisal",src:"Federal"},{name:"Appraisal Invoice",src:"Federal"},{name:"Credit Report Invoice",src:"Federal"},{name:"Settlement Service Provider List",src:"Federal"},{name:"Initial Privacy Notice",src:"Federal"},{name:"Fee Agreement",src:"Federal"},{name:"Verification of Employment",src:"Federal"},{name:"Verification of Income",src:"Federal"}] },
  { id:"LN-2026-0853", borrower:"Williams, Donna", state:"CA", property:"1600 Sunset Blvd, Los Angeles, CA 90028", purpose:"Purchase", product:"VA", type:"Fixed", lien:"First", occupancy:"Primary", stage:"Underwriting", rate:5.75, amount:725000, term:30, docsComplete:28, docsRequired:46, originator:"James Chen", originatorNmls:"1234567", lender:"US Bank", lenderNmls:"504713", appDate:"2026-01-28", closingDate:null, daysInStage:5, score:61, alerts:2, missingDocs:[{name:"CA Broker Agreement",src:"CA"},{name:"CA DRE Disclosure",src:"CA"},{name:"Credit Score Disclosure",src:"Federal"},{name:"Appraisal Invoice",src:"Federal"},{name:"Fee Agreement",src:"Federal"},{name:"Rate Lock Agreement",src:"Federal"},{name:"Verification of Employment",src:"Federal"},{name:"Title Policy",src:"Federal"}] },
  { id:"LN-2026-0860", borrower:"Patel, Rajesh", state:"FL", property:"8400 Collins Ave, Miami, FL 33141", purpose:"Purchase", product:"Conventional", type:"ARM", lien:"First", occupancy:"Investment", stage:"Application", rate:6.5, amount:590000, term:30, docsComplete:5, docsRequired:40, originator:"Sarah Kim", originatorNmls:"2345678", lender:"Pending", lenderNmls:"—", appDate:"2026-03-17", closingDate:null, daysInStage:2, score:13, alerts:5, missingDocs:[{name:"FL Mortgage Brokerage Disclosure",src:"FL"},{name:"Initial Loan Estimate",src:"Federal"},{name:"Intent to Proceed",src:"Federal"},{name:"Credit Report",src:"Federal"},{name:"ARM Program Disclosure",src:"Federal"}] },
  { id:"LN-2026-0862", borrower:"Thompson, Angela", state:"TX", property:"900 W 5th St, Austin, TX 78703", purpose:"Home Equity 50(a)(6)", product:"Conventional", type:"Fixed", lien:"First", occupancy:"Primary", stage:"Closing", rate:7.125, amount:180000, term:15, docsComplete:44, docsRequired:48, originator:"James Chen", originatorNmls:"1234567", lender:"Guaranty Bank", lenderNmls:"716436", appDate:"2026-02-10", closingDate:"2026-03-20", daysInStage:1, score:92, alerts:1, missingDocs:[{name:"TX Home Equity Disclosure 50(a)(6)",src:"TX"},{name:"Acknowledgement of Fair Market Value",src:"TX"},{name:"Discount Point Acknowledgement",src:"TX"},{name:"TX Notice of Penalties",src:"TX"}] },
  { id:"LN-2026-0865", borrower:"Garcia, Luis", state:"NY", property:"455 Park Ave, New York, NY 10022", purpose:"Purchase", product:"Conventional", type:"Fixed", lien:"First", occupancy:"Primary", stage:"Processing", rate:6.25, amount:1200000, term:30, docsComplete:15, docsRequired:43, originator:"James Chen", originatorNmls:"1234567", lender:"JPMorgan", lenderNmls:"602670", appDate:"2026-02-20", closingDate:null, daysInStage:9, score:35, alerts:3, missingDocs:[{name:"NY DFS Disclosure Form",src:"NY"},{name:"Credit Score Disclosure",src:"Federal"},{name:"Appraisal",src:"Federal"},{name:"Appraisal Invoice",src:"Federal"},{name:"Fee Agreement",src:"Federal"},{name:"Rate Lock Agreement",src:"Federal"}] },
  { id:"LN-2026-0869", borrower:"Davis, Robert", state:"AZ", property:"3200 N Scottsdale Rd, Scottsdale, AZ 85251", purpose:"Refinance", product:"Conventional", type:"Fixed", lien:"First", occupancy:"Primary", stage:"Post-Close", rate:6.0, amount:420000, term:30, docsComplete:41, docsRequired:41, originator:"Sarah Kim", originatorNmls:"2345678", lender:"Flagstar", lenderNmls:"417490", appDate:"2026-01-05", closingDate:"2026-03-01", daysInStage:18, score:100, alerts:0, missingDocs:[] },
  { id:"LN-2026-0872", borrower:"Nguyen, Thanh", state:"CO", property:"1200 Pearl St, Boulder, CO 80302", purpose:"Purchase", product:"Conventional", type:"Fixed", lien:"First", occupancy:"Secondary", stage:"Underwriting", rate:6.625, amount:510000, term:30, docsComplete:22, docsRequired:41, originator:"Sarah Kim", originatorNmls:"2345678", lender:"Rocket Mortgage", lenderNmls:"3030", appDate:"2026-02-14", closingDate:null, daysInStage:4, score:54, alerts:2, missingDocs:[{name:"CO Broker Disclosure",src:"CO"},{name:"Fee Agreement",src:"Federal"},{name:"Rate Lock Agreement",src:"Federal"},{name:"Credit Score Disclosure",src:"Federal"},{name:"Appraisal Invoice",src:"Federal"}] },
];

const STAGES = ["Application","Processing","Underwriting","Closing","Post-Close"];
const PROGRAMS = [
  { name:"Anti-Money Laundering Program", required:true, status:"current", lastReview:"Nov 15, 2025", nextReview:"Nov 15, 2026" },
  { name:"Identity Theft Prevention (Red Flags)", required:true, status:"current", lastReview:"Oct 1, 2025", nextReview:"Oct 1, 2026" },
  { name:"Information Security Program", required:true, status:"overdue", lastReview:"Jan 20, 2025", nextReview:"Jan 20, 2026" },
  { name:"Compensation Agreements", required:true, status:"current", lastReview:"Jan 5, 2026", nextReview:"Jan 5, 2027" },
  { name:"Remote Work Policy", required:true, status:"current", lastReview:"Sep 12, 2025", nextReview:"Sep 12, 2026" },
  { name:"Quality Control Manual", required:false, status:"missing", lastReview:null, nextReview:null },
];
const DEADLINES = [
  { report:"Financial Condition (Annual)", due:"Mar 31, 2026", daysLeft:12, status:"urgent" },
  { report:"RMLA + SSSF (Q1 2026)", due:"May 15, 2026", daysLeft:57, status:"upcoming" },
  { report:"RMLA + SSSF (Q4 2025)", due:"Feb 14, 2026", daysLeft:-33, status:"filed" },
];
const TX_LOG_FIELDS = ["Loan #","Borrower","App Date","Property","Rate","Purpose","Product","Type","Term","Lien","Occupancy","Status","Close Date","Originator","NMLS","Lender","Lender NMLS"];

/* ═══ COMPONENTS ═══ */
const Badge = ({color, bg, children}) => <span style={{display:"inline-flex",alignItems:"center",padding:"2px 10px",borderRadius:"20px",fontSize:"11px",fontWeight:600,color,background:bg,whiteSpace:"nowrap"}}>{children}</span>;

const ScoreRing = ({score, size=56}) => {
  const r=(size-8)/2, ci=2*Math.PI*r, o=ci-(score/100)*ci, col=scoreColor(score);
  return <div style={{position:"relative",width:size,height:size,flexShrink:0}}>
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={T.g200} strokeWidth="3.5"/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={col} strokeWidth="3.5" strokeDasharray={ci} strokeDashoffset={o} strokeLinecap="round" transform={`rotate(-90 ${size/2} ${size/2})`} style={{transition:"stroke-dashoffset 0.5s ease"}}/>
    </svg>
    <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size>50?"15px":"11px",fontWeight:700,color:col}}>{score}</div>
  </div>;
};

const ProgressBar = ({value,max,h=6}) => {
  const pct=Math.round((value/max)*100), col=scoreColor(pct);
  return <div style={{display:"flex",alignItems:"center",gap:"8px"}}>
    <div style={{flex:1,height:h,background:T.g200,borderRadius:h/2,overflow:"hidden"}}>
      <div style={{width:`${pct}%`,height:"100%",background:col,borderRadius:h/2,transition:"width 0.4s ease"}}/>
    </div>
    <span style={{fontSize:"11px",color:T.g500,minWidth:"44px",textAlign:"right",fontWeight:500}}>{value}/{max}</span>
  </div>;
};

const MetricCard = ({label,value,sub,accent}) => <div style={{background:T.white,borderRadius:T.radiusLg,padding:"16px 20px",border:`1px solid ${T.g200}`,boxShadow:"0 1px 3px rgba(27,58,107,0.06)"}}>
  <div style={{fontSize:"10px",color:T.g500,textTransform:"uppercase",letterSpacing:"0.8px",fontWeight:600,marginBottom:"5px"}}>{label}</div>
  <div style={{fontSize:"24px",fontWeight:700,color:accent||T.royal,lineHeight:1.2}}>{value}</div>
  {sub && <div style={{fontSize:"11px",color:T.g500,marginTop:"4px"}}>{sub}</div>}
</div>;

const Pill = ({active,onClick,children}) => <button onClick={onClick} style={{padding:"6px 14px",fontSize:"12px",fontWeight:active?600:400,color:active?T.white:T.g700,background:active?T.royal:"transparent",border:active?"none":`1px solid ${T.g200}`,borderRadius:"20px",cursor:"pointer",transition:"all 0.15s",whiteSpace:"nowrap"}}>{children}</button>;

/* ═══ MAIN APP ═══ */
export default function MortgageGuardApp() {
  const [tab, setTab] = useState("dashboard");
  const [stateFilter, setStateFilter] = useState("all");
  const [stageFilter, setStageFilter] = useState("all");
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [search, setSearch] = useState("");
  const [sidebar, setSidebar] = useState(true);

  const filtered = useMemo(() => {
    let f = LOANS;
    if (stateFilter !== "all") f = f.filter(l => l.state === stateFilter);
    if (stageFilter !== "all") f = f.filter(l => l.stage === stageFilter);
    if (search) { const q = search.toLowerCase(); f = f.filter(l => l.borrower.toLowerCase().includes(q) || l.id.toLowerCase().includes(q)); }
    return f;
  }, [stateFilter, stageFilter, search]);

  const avgScore = filtered.length ? Math.round(filtered.reduce((a,l) => a+l.score,0)/filtered.length) : 0;
  const criticals = filtered.filter(l => l.score<50).length;
  const totalVol = filtered.reduce((a,l) => a+l.amount,0);
  const totalAlerts = filtered.reduce((a,l) => a+l.alerts,0);
  const programIssues = PROGRAMS.filter(p => p.status !== "current").length;

  const navItems = [
    {id:"dashboard",label:"Dashboard"},
    {id:"pipeline",label:"Loan pipeline"},
    {id:"txlog",label:"Transaction log"},
    {id:"programs",label:"Compliance programs"},
    {id:"deadlines",label:"Reporting calendar"},
    {id:"rules",label:"State rules engine"},
  ];

  // ─── SIDEBAR ───
  const Sidebar = () => <div style={{width:sidebar?220:0,minWidth:sidebar?220:0,background:T.royal,color:T.white,display:"flex",flexDirection:"column",transition:"all 0.2s",overflow:"hidden",borderRadius:"12px 0 0 12px"}}>
    <div style={{padding:"18px 16px 12px",display:"flex",alignItems:"center",gap:"10px",borderBottom:"1px solid rgba(255,255,255,0.1)"}}>
      <div style={{width:30,height:30,borderRadius:"8px",background:T.green,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:"13px",flexShrink:0}}>MG</div>
      <div><div style={{fontWeight:700,fontSize:"14px"}}>MortgageGuard</div><div style={{fontSize:"10px",opacity:0.6}}>Compliance CRM</div></div>
    </div>
    <nav style={{flex:1,padding:"8px"}}>
      {navItems.map(n => <button key={n.id} onClick={() => {setTab(n.id);setSelectedLoan(null);}} style={{width:"100%",display:"flex",alignItems:"center",padding:"9px 12px",fontSize:"12px",fontWeight:tab===n.id?600:400,color:tab===n.id?T.white:"rgba(255,255,255,0.6)",background:tab===n.id?"rgba(255,255,255,0.12)":"transparent",border:"none",borderRadius:T.radiusSm,cursor:"pointer",transition:"all 0.12s",textAlign:"left",marginBottom:"2px"}}>{n.label}</button>)}
    </nav>
  </div>;

  // ─── HEADER ───
  const Header = () => <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 24px",background:T.white,borderBottom:`1px solid ${T.g200}`,flexWrap:"wrap",gap:"10px"}}>
    <div>
      <div style={{display:"flex",alignItems:"center",gap:"8px"}}>
        {!sidebar && <button onClick={()=>setSidebar(true)} style={{background:"none",border:"none",cursor:"pointer",fontSize:"18px",color:T.royal}}>☰</button>}
        <h1 style={{fontSize:"18px",fontWeight:700,color:T.royal,margin:0}}>{navItems.find(n=>n.id===tab)?.label}</h1>
      </div>
      <p style={{fontSize:"11px",color:T.g500,margin:"2px 0 0"}}>March 19, 2026</p>
    </div>
    <div style={{display:"flex",gap:"8px",alignItems:"center"}}>
      <select value={stateFilter} onChange={e=>setStateFilter(e.target.value)} style={{padding:"6px 10px",fontSize:"11px",borderRadius:T.radiusSm,border:`1px solid ${T.g200}`,background:T.white,color:T.g700}}>
        <option value="all">All states</option>
        {[...new Set(LOANS.map(l=>l.state))].sort().map(s=><option key={s} value={s}>{s}</option>)}
      </select>
      <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search loans..." style={{padding:"6px 10px",fontSize:"11px",borderRadius:T.radiusSm,border:`1px solid ${T.g200}`,width:"150px",color:T.g700}}/>
      {sidebar && <button onClick={()=>setSidebar(false)} style={{background:"none",border:`1px solid ${T.g200}`,borderRadius:T.radiusSm,padding:"4px 8px",cursor:"pointer",fontSize:"11px",color:T.g500}}>◁</button>}
    </div>
  </div>;

  // ─── DASHBOARD ───
  const DashboardTab = () => <div style={{padding:"20px 24px"}}>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(145px, 1fr))",gap:"12px",marginBottom:"24px"}}>
      <MetricCard label="Exam readiness" value={`${avgScore}%`} sub={avgScore>=80?"Passing":"Below threshold"} accent={scoreColor(avgScore)}/>
      <MetricCard label="Active loans" value={filtered.length} sub={fmt(totalVol)+" volume"}/>
      <MetricCard label="Critical alerts" value={criticals} sub="Below 50% score" accent={criticals>0?T.red:T.green}/>
      <MetricCard label="Open alerts" value={totalAlerts} sub="Doc, policy, reporting" accent={totalAlerts>3?T.amber:T.green}/>
      <MetricCard label="Program issues" value={programIssues} sub={programIssues>0?"Action needed":"All current"} accent={programIssues>0?T.amber:T.green}/>
    </div>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"16px"}}>
      <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"18px 20px"}}>
        <div style={{fontSize:"13px",fontWeight:600,color:T.royal,marginBottom:"12px"}}>Loans requiring attention</div>
        {filtered.filter(l=>l.score<80).sort((a,b)=>a.score-b.score).slice(0,4).map(loan =>
          <div key={loan.id} onClick={()=>{setTab("pipeline");setSelectedLoan(loan.id);}} style={{display:"flex",alignItems:"center",gap:"12px",padding:"10px 0",borderBottom:`1px solid ${T.g100}`,cursor:"pointer"}}>
            <ScoreRing score={loan.score} size={40}/>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:"12px",fontWeight:600,color:T.g900}}>{loan.borrower}</div>
              <div style={{fontSize:"10px",color:T.g500}}>{loan.id} · {loan.state} · {loan.stage} · {loan.docsComplete}/{loan.docsRequired} docs</div>
            </div>
            <Badge color={scoreColor(loan.score)} bg={scoreBg(loan.score)}>{loan.score}%</Badge>
          </div>
        )}
      </div>
      <div>
        <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"18px 20px",marginBottom:"16px"}}>
          <div style={{fontSize:"13px",fontWeight:600,color:T.royal,marginBottom:"12px"}}>Upcoming deadlines</div>
          {DEADLINES.filter(d=>d.status!=="filed").sort((a,b)=>a.daysLeft-b.daysLeft).map((d,i) =>
            <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${T.g100}`}}>
              <div><div style={{fontSize:"12px",fontWeight:500,color:T.g900}}>{d.report}</div><div style={{fontSize:"10px",color:T.g500}}>Due {d.due}</div></div>
              <Badge color={d.daysLeft<=14?T.red:T.amber} bg={d.daysLeft<=14?T.redPale:T.amberPale}>{d.daysLeft}d</Badge>
            </div>
          )}
        </div>
        <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"18px 20px"}}>
          <div style={{fontSize:"13px",fontWeight:600,color:T.royal,marginBottom:"12px"}}>Pipeline snapshot</div>
          <div style={{display:"flex",gap:"4px"}}>
            {STAGES.map(s => {
              const cnt = filtered.filter(l=>l.stage===s).length;
              return <div key={s} onClick={()=>{setTab("pipeline");setStageFilter(s);}} style={{flex:1,textAlign:"center",padding:"10px 2px",borderRadius:T.radiusSm,background:cnt>0?T.royalPale:T.g50,border:`1px solid ${cnt>0?T.royalPale:T.g200}`,cursor:"pointer"}}>
                <div style={{fontSize:"18px",fontWeight:700,color:cnt>0?T.royal:T.g300}}>{cnt}</div>
                <div style={{fontSize:"8px",fontWeight:600,textTransform:"uppercase",letterSpacing:"0.3px",color:cnt>0?T.g700:T.g500,marginTop:"2px"}}>{s.replace("Post-Close","Post")}</div>
              </div>;
            })}
          </div>
        </div>
      </div>
    </div>
  </div>;

  // ─── LOAN DETAIL ───
  const LoanDetail = ({loan}) => {
    const stageIdx = STAGES.indexOf(loan.stage);
    return <div style={{padding:"20px 24px"}}>
      <button onClick={()=>setSelectedLoan(null)} style={{display:"inline-flex",alignItems:"center",gap:"4px",padding:"5px 12px",fontSize:"11px",fontWeight:500,color:T.royal,background:T.royalPale,border:"none",borderRadius:"20px",cursor:"pointer",marginBottom:"16px"}}>← Back</button>

      <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"20px",marginBottom:"16px"}}>
        <div style={{display:"flex",gap:"16px",alignItems:"flex-start",flexWrap:"wrap"}}>
          <ScoreRing score={loan.score} size={70}/>
          <div style={{flex:1,minWidth:200}}>
            <div style={{display:"flex",alignItems:"center",gap:"8px",flexWrap:"wrap",marginBottom:"4px"}}>
              <span style={{fontSize:"18px",fontWeight:700,color:T.royal}}>{loan.borrower}</span>
              <Badge color={T.royal} bg={T.royalPale}>{loan.state}</Badge>
              <Badge color={scoreColor(loan.score)} bg={scoreBg(loan.score)}>{loan.stage}</Badge>
              {loan.purpose.includes("50(a)(6)") && <Badge color={T.amber} bg={T.amberPale}>TX Home Equity</Badge>}
            </div>
            <div style={{fontSize:"12px",color:T.g500}}>{loan.id} · {loan.property}</div>
            <div style={{fontSize:"12px",color:T.g500}}>Applied {loan.appDate} · {loan.daysInStage}d in stage</div>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(110px, 1fr))",gap:"10px",marginTop:"16px"}}>
          {[["Amount",fmt(loan.amount)],["Rate",loan.rate+"%"],["Term",loan.term+"yr "+loan.type],["Product",loan.product],["Lien",loan.lien],["Occupancy",loan.occupancy],["Lender",loan.lender],["Originator",loan.originator]].map(([l,v])=>
            <div key={l} style={{background:T.g50,borderRadius:T.radiusSm,padding:"8px 12px"}}>
              <div style={{fontSize:"9px",color:T.g500,textTransform:"uppercase",letterSpacing:"0.5px",fontWeight:600}}>{l}</div>
              <div style={{fontSize:"13px",fontWeight:600,color:T.g900,marginTop:"2px"}}>{v}</div>
            </div>
          )}
        </div>
      </div>

      {/* Compliance gates */}
      <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"16px 20px",marginBottom:"16px"}}>
        <div style={{fontSize:"13px",fontWeight:600,color:T.royal,marginBottom:"10px"}}>Compliance gates</div>
        <div style={{display:"flex",gap:"3px"}}>
          {STAGES.map((s,i) => {
            const past=i<stageIdx, curr=i===stageIdx;
            return <div key={s} style={{flex:1,textAlign:"center",padding:"10px 2px",borderRadius:T.radiusSm,background:past?T.greenPale:curr?T.royalPale:T.g50,border:curr?`2px solid ${T.royal}`:`1px solid ${past?T.greenPale:T.g200}`}}>
              <div style={{fontSize:"12px",fontWeight:600,color:past?T.green:curr?T.royal:T.g300}}>{past?"✓":curr?"●":"○"}</div>
              <div style={{fontSize:"9px",fontWeight:600,textTransform:"uppercase",color:past?T.green:curr?T.royal:T.g500,marginTop:"3px"}}>{s}</div>
            </div>;
          })}
        </div>
      </div>

      {/* Document completeness */}
      <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"16px 20px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"10px"}}>
          <div style={{fontSize:"13px",fontWeight:600,color:T.royal}}>Document completeness</div>
          <Badge color={scoreColor(Math.round(loan.docsComplete/loan.docsRequired*100))} bg={scoreBg(Math.round(loan.docsComplete/loan.docsRequired*100))}>{Math.round(loan.docsComplete/loan.docsRequired*100)}%</Badge>
        </div>
        <ProgressBar value={loan.docsComplete} max={loan.docsRequired} h={7}/>
        {loan.missingDocs.length>0 && <div style={{marginTop:"14px"}}>
          <div style={{fontSize:"11px",fontWeight:600,color:T.red,textTransform:"uppercase",letterSpacing:"0.4px",marginBottom:"8px"}}>Missing ({loan.missingDocs.length})</div>
          {loan.missingDocs.slice(0,8).map((doc,i) =>
            <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"7px 10px",background:i%2===0?T.g50:T.white,borderRadius:T.radiusSm,fontSize:"12px",color:T.g700,marginBottom:"2px"}}>
              <span>{doc.name}</span>
              <Badge color={doc.src!=="Federal"?T.royal:T.g500} bg={doc.src!=="Federal"?T.royalPale:T.g100}>{doc.src}</Badge>
            </div>
          )}
          {loan.missingDocs.length>8 && <div style={{fontSize:"11px",color:T.g500,padding:"6px 0",textAlign:"center"}}>+ {loan.missingDocs.length-8} more</div>}
        </div>}
      </div>
    </div>;
  };

  // ─── PIPELINE ───
  const PipelineTab = () => {
    if (selectedLoan) { const loan = LOANS.find(l=>l.id===selectedLoan); if (loan) return <LoanDetail loan={loan}/>; }
    return <div style={{padding:"20px 24px"}}>
      <div style={{display:"flex",gap:"5px",marginBottom:"16px",flexWrap:"wrap"}}>
        <Pill active={stageFilter==="all"} onClick={()=>setStageFilter("all")}>All</Pill>
        {STAGES.map(s=><Pill key={s} active={stageFilter===s} onClick={()=>setStageFilter(s)}>{s} ({filtered.filter(l=>l.stage===s).length})</Pill>)}
      </div>
      <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,overflow:"hidden"}}>
        <div style={{display:"grid",gridTemplateColumns:"minmax(0,2fr) 50px 80px 70px 100px 100px 50px",gap:"10px",padding:"10px 16px",background:T.g50,borderBottom:`1px solid ${T.g200}`,fontSize:"9px",fontWeight:600,color:T.g500,textTransform:"uppercase",letterSpacing:"0.5px"}}>
          <div>Borrower</div><div>State</div><div>Stage</div><div>Score</div><div>Docs</div><div>Amount</div><div>Days</div>
        </div>
        {filtered.map(loan =>
          <div key={loan.id} onClick={()=>setSelectedLoan(loan.id)} style={{display:"grid",gridTemplateColumns:"minmax(0,2fr) 50px 80px 70px 100px 100px 50px",gap:"10px",padding:"12px 16px",borderBottom:`1px solid ${T.g100}`,cursor:"pointer",alignItems:"center",transition:"background 0.1s"}} onMouseEnter={e=>e.currentTarget.style.background=T.g50} onMouseLeave={e=>e.currentTarget.style.background=T.white}>
            <div><div style={{fontSize:"12px",fontWeight:600,color:T.g900,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{loan.borrower}</div><div style={{fontSize:"10px",color:T.g500}}>{loan.id} · {loan.purpose}</div></div>
            <div><Badge color={T.royal} bg={T.royalPale}>{loan.state}</Badge></div>
            <div><Badge color={scoreColor(loan.score)} bg={scoreBg(loan.score)}>{loan.stage}</Badge></div>
            <div><ScoreRing score={loan.score} size={34}/></div>
            <div><ProgressBar value={loan.docsComplete} max={loan.docsRequired} h={4}/></div>
            <div style={{fontSize:"12px",fontWeight:500,color:T.g700}}>{fmt(loan.amount)}</div>
            <div style={{fontSize:"11px",color:loan.daysInStage>7?T.amber:T.g500,fontWeight:loan.daysInStage>7?600:400}}>{loan.daysInStage}d</div>
          </div>
        )}
      </div>
    </div>;
  };

  // ─── TX LOG ───
  const TxLogTab = () => <div style={{padding:"20px 24px"}}>
    <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"16px 20px"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"4px"}}>
        <div style={{fontSize:"13px",fontWeight:600,color:T.royal}}>Mortgage transaction log</div>
        <Badge color={T.green} bg={T.greenPale}>Within 7-day window</Badge>
      </div>
      <div style={{fontSize:"11px",color:T.g500,marginBottom:"14px"}}>All 17 TX-SML required fields. Auto-populated from loan data.</div>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:"11px"}}>
          <thead><tr style={{background:T.royalPale}}>
            {TX_LOG_FIELDS.map(f=><th key={f} style={{padding:"7px 8px",textAlign:"left",fontWeight:600,color:T.royal,borderBottom:`2px solid ${T.royal}`,whiteSpace:"nowrap",fontSize:"9px",textTransform:"uppercase",letterSpacing:"0.3px"}}>{f}</th>)}
          </tr></thead>
          <tbody>{filtered.map((l,i)=>
            <tr key={l.id} style={{background:i%2===0?T.white:T.g50}}>
              <td style={{padding:"6px 8px",color:T.royal,fontWeight:600,whiteSpace:"nowrap"}}>{l.id}</td>
              <td style={{padding:"6px 8px",whiteSpace:"nowrap"}}>{l.borrower}</td>
              <td style={{padding:"6px 8px"}}>{l.appDate}</td>
              <td style={{padding:"6px 8px",maxWidth:"160px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{l.property}</td>
              <td style={{padding:"6px 8px"}}>{l.rate}%</td>
              <td style={{padding:"6px 8px",whiteSpace:"nowrap"}}>{l.purpose}</td>
              <td style={{padding:"6px 8px"}}>{l.product}</td>
              <td style={{padding:"6px 8px"}}>{l.type}</td>
              <td style={{padding:"6px 8px"}}>{l.term}yr</td>
              <td style={{padding:"6px 8px"}}>{l.lien}</td>
              <td style={{padding:"6px 8px"}}>{l.occupancy}</td>
              <td style={{padding:"6px 8px"}}><Badge color={l.stage==="Post-Close"?T.green:T.royal} bg={l.stage==="Post-Close"?T.greenPale:T.royalPale}>{l.stage==="Post-Close"?"Closed":"In-Process"}</Badge></td>
              <td style={{padding:"6px 8px"}}>{l.closingDate||"—"}</td>
              <td style={{padding:"6px 8px",whiteSpace:"nowrap"}}>{l.originator}</td>
              <td style={{padding:"6px 8px"}}>{l.originatorNmls}</td>
              <td style={{padding:"6px 8px",whiteSpace:"nowrap"}}>{l.lender}</td>
              <td style={{padding:"6px 8px"}}>{l.lenderNmls}</td>
            </tr>
          )}</tbody>
        </table>
      </div>
    </div>
  </div>;

  // ─── PROGRAMS ───
  const ProgramsTab = () => <div style={{padding:"20px 24px"}}>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"12px",marginBottom:"20px"}}>
      <MetricCard label="Total programs" value={PROGRAMS.length} sub={PROGRAMS.filter(p=>p.required).length+" required"}/>
      <MetricCard label="Current" value={PROGRAMS.filter(p=>p.status==="current").length} accent={T.green}/>
      <MetricCard label="Action needed" value={programIssues} accent={programIssues>0?T.red:T.green}/>
    </div>
    <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,overflow:"hidden"}}>
      {PROGRAMS.map((p,i) => <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 20px",borderBottom:i<PROGRAMS.length-1?`1px solid ${T.g100}`:"none",flexWrap:"wrap",gap:"8px"}}>
        <div style={{flex:1,minWidth:200}}>
          <div style={{display:"flex",alignItems:"center",gap:"6px",marginBottom:"3px"}}>
            <span style={{fontSize:"13px",fontWeight:600,color:T.g900}}>{p.name}</span>
            {p.required && <Badge color={T.royal} bg={T.royalPale}>Required</Badge>}
          </div>
          <div style={{fontSize:"11px",color:T.g500}}>{p.lastReview?`Reviewed ${p.lastReview}`:"Never reviewed"}{p.nextReview&&` · Due ${p.nextReview}`}</div>
        </div>
        <Badge color={p.status==="current"?T.green:p.status==="overdue"?T.amber:T.red} bg={p.status==="current"?T.greenPale:p.status==="overdue"?T.amberPale:T.redPale}>{p.status==="current"?"✓ Current":p.status==="overdue"?"⚠ Overdue":"✕ Missing"}</Badge>
      </div>)}
    </div>
    {PROGRAMS.some(p=>p.status!=="current"&&p.required) && <div style={{marginTop:"14px",padding:"12px 16px",background:T.redPale,border:`1px solid #F09595`,borderRadius:T.radiusLg,fontSize:"12px",color:T.red}}><strong>Exam risk:</strong> Required programs that are missing or overdue will be cited as deficiencies.</div>}
  </div>;

  // ─── DEADLINES ───
  const DeadlinesTab = () => <div style={{padding:"20px 24px"}}>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"10px",marginBottom:"20px"}}>
      {[["Q1 → May 15","Jan 1 – Mar 31"],["Q2 → Aug 14","Apr 1 – Jun 30"],["Q3 → Nov 14","Jul 1 – Sep 30"],["Q4 → Feb 14","Oct 1 – Dec 31"]].map(([q,period],i)=>
        <div key={i} style={{background:i===0?T.royalPale:T.white,border:`1px solid ${i===0?T.royal:T.g200}`,borderRadius:T.radiusLg,padding:"12px 14px",textAlign:"center"}}>
          <div style={{fontSize:"13px",fontWeight:700,color:i===0?T.royal:T.g700}}>{q}</div>
          <div style={{fontSize:"10px",color:i===0?T.royalLight:T.g500,marginTop:"3px"}}>{period}</div>
          {i===0 && <div style={{fontSize:"9px",fontWeight:600,color:T.green,marginTop:"4px",textTransform:"uppercase"}}>Current</div>}
        </div>
      )}
    </div>
    <div style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,overflow:"hidden"}}>
      {DEADLINES.sort((a,b)=>a.daysLeft-b.daysLeft).map((d,i) => <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 20px",borderBottom:i<DEADLINES.length-1?`1px solid ${T.g100}`:"none"}}>
        <div><div style={{fontSize:"13px",fontWeight:600,color:T.g900}}>{d.report}</div><div style={{fontSize:"11px",color:T.g500}}>Due {d.due}</div></div>
        <div style={{display:"flex",alignItems:"center",gap:"8px"}}>
          {d.status!=="filed" && <span style={{fontSize:"13px",fontWeight:700,color:d.daysLeft<=14?T.red:T.amber}}>{d.daysLeft}d</span>}
          <Badge color={d.status==="filed"?T.green:d.status==="urgent"?T.red:T.amber} bg={d.status==="filed"?T.greenPale:d.status==="urgent"?T.redPale:T.amberPale}>{d.status==="filed"?"✓ Filed":d.status==="urgent"?"Urgent":"Upcoming"}</Badge>
        </div>
      </div>)}
    </div>
  </div>;

  // ─── RULES ENGINE ───
  const RulesTab = () => <div style={{padding:"20px 24px"}}>
    <div style={{fontSize:"12px",color:T.g500,marginBottom:"16px"}}>State-specific compliance requirements mapped to document checklists and pipeline gates.</div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(180px, 1fr))",gap:"12px"}}>
      {[{code:"TX",name:"Texas",agency:"TX-SML",rules:48},{code:"CA",name:"California",agency:"CA-DFPI",rules:52},{code:"FL",name:"Florida",agency:"FL-OFR",rules:44},{code:"NY",name:"New York",agency:"NY-DFS",rules:50},{code:"AZ",name:"Arizona",agency:"AZ-DIFI",rules:42},{code:"CO",name:"Colorado",agency:"CO-DORA",rules:41}].map(st => {
        const stLoans = LOANS.filter(l=>l.state===st.code);
        const stAvg = stLoans.length?Math.round(stLoans.reduce((a,l)=>a+l.score,0)/stLoans.length):0;
        return <div key={st.code} style={{background:T.white,borderRadius:T.radiusLg,border:`1px solid ${T.g200}`,padding:"16px"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"10px"}}>
            <div><div style={{fontSize:"18px",fontWeight:700,color:T.royal}}>{st.code}</div><div style={{fontSize:"11px",color:T.g500}}>{st.name}</div></div>
            {stLoans.length>0 && <ScoreRing score={stAvg} size={38}/>}
          </div>
          <div style={{fontSize:"11px",color:T.g500,marginBottom:"8px"}}>Agency: <strong style={{color:T.g700}}>{st.agency}</strong></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"6px"}}>
            <div style={{background:T.g50,borderRadius:T.radiusSm,padding:"6px 8px",textAlign:"center"}}><div style={{fontSize:"14px",fontWeight:700,color:T.royal}}>{st.rules}</div><div style={{fontSize:"8px",color:T.g500,textTransform:"uppercase"}}>Rules</div></div>
            <div style={{background:T.g50,borderRadius:T.radiusSm,padding:"6px 8px",textAlign:"center"}}><div style={{fontSize:"14px",fontWeight:700,color:T.royal}}>{stLoans.length}</div><div style={{fontSize:"8px",color:T.g500,textTransform:"uppercase"}}>Loans</div></div>
          </div>
        </div>;
      })}
    </div>
  </div>;

  const tabs = { dashboard:<DashboardTab/>, pipeline:<PipelineTab/>, txlog:<TxLogTab/>, programs:<ProgramsTab/>, deadlines:<DeadlinesTab/>, rules:<RulesTab/> };

  return <div style={{display:"flex",height:"100vh",maxHeight:"820px",fontFamily:T.font,background:T.g100,borderRadius:"12px",overflow:"hidden",border:`1px solid ${T.g200}`,boxShadow:"0 4px 12px rgba(27,58,107,0.1)"}}>
    <Sidebar/>
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0}}>
      <Header/>
      <div style={{flex:1,overflowY:"auto",background:T.g50}}>{tabs[tab]}</div>
    </div>
  </div>;
}
